"use strict";
module.exports = require("./lib/obj2gltf");
